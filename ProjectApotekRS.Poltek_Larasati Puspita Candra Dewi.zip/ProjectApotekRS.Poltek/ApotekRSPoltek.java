import java.util.Scanner;
import java.util.Date;
public class ApotekRSPoltek {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int menu, jenisObat;
        String operator= "", password= "";
        boolean ulangi = true;
        boolean struk = true;
        Date date = new Date();
        System.out.print("Masukkan nama operator: ");
        operator = sc.nextLine();
        System.out.print("Masukkan password: ");
        password = sc.nextLine();
       
        if (operator.equals("admin") && password.equals("poltek") ) {
            System.out.println("Login Berhasil!");
        while (ulangi == true) {
            System.out.print("Apakah yang ingin anda lakukan? (1) Stok Obat atau (2) Transaksi ? ");
            menu = sc.nextInt();
            if (menu == 1) {
                System.out.print("Masukkan jumlah jenis obat: ");
                jenisObat = sc.nextInt();
                int dataObat[][] = new int[jenisObat][2];
                String[] namaObat = new String[jenisObat];
                String[] expObat = new String[jenisObat];
                for (int i = 0; i < jenisObat; i++) {
                    System.out.println("------------------------");
                    System.out.println("Masukkan data obat ke-" + (i + 1));
                    System.out.print("Masukkan nama obat: ");
                    namaObat[i] = sc.next();
                    System.out.print("Masukkan exp obat: ");
                    expObat[i] = sc.next();
                    for (int j = 0; j < dataObat[0].length; j++) {
                        switch (j) {
                            case 0:
                                System.out.print("Masukkan stok obat: ");
                                dataObat[i][j] = sc.nextInt();
                                break;
                            case 1:
                                System.out.print("Masukkan harga: ");
                                dataObat[i][j] = sc.nextInt();
                                break;
                        }
                    }
                }

                System.out.println("======================================================================");
                System.out.println("\t\t\t" + "Data Obat Apotik RS.Poltek");
                System.out.println("======================================================================");
                System.out.print("Nama Obat" + "\t\t" + "Exp" + "\t\t\t" + "Qty" + "\t\t" + "Harga");
                System.out.println();
                for (int i = 0; i < dataObat.length; i++) {
                    System.out.print(namaObat[i] + "\t\t" + expObat[i] + "\t\t");
                    for (int j = 0; j < dataObat[0].length; j++) {
                        System.out.print(dataObat[i][j] + "\t\t");
                    }
                    ;
                    System.out.println();
                }

            } else if (menu == 2) {
                System.out.print("Masukkan jenis pembeli/pasien [umum/bpjs/asuransi]: ");
                String jenisPasien = sc.next();
                System.out.print("Masukkan nama pembeli/pasien: ");
                String namaPasien = sc.next();
                System.out.print("Masukkan jumlah resep/jenis obat :");
                int resep = sc.nextInt();
                int subtotal = 0, total =0;
                int dataObat[][] = new int[resep][2];
                String[] namaObat = new String[resep];
                for (int i = 0; i < dataObat.length; i++) {
                    System.out.println("------------------------");
                    System.out.println("Jenis obat ke-" + (i + 1));
                    System.out.print("Masukkan nama obat: ");
                    namaObat[i] = sc.next();
                    for (int j = 0; j < dataObat[0].length; j++) {
                        switch (j) {
                            case 0:
                                System.out.print("Masukkan jumlah obat: ");
                                dataObat[i][j] = sc.nextInt();
                                break;
                            case 1:
                                System.out.print("Masukkan harga obat: ");
                                dataObat[i][j] = sc.nextInt();
                                break;
                            
                        }
                    }
                }
                System.out.print("Apakah anda ingin cetak struk? [true/false]:");
                struk = sc.nextBoolean();
                if(struk == true){
                    System.out.println("======================================================================");
                    System.out.println("\t\t\t" + "Struk Obat Apotik RS.Poltek");
                    System.out.println("\t\t" + "Jl. Soekarno Hatta No 01, Kota Malang");
                    System.out.println("======================================================================");
                    System.out.println("Operator: " + operator);
                    System.out.println(date.toString());
                    System.out.println("Pembeli: " + namaPasien);
                    System.out.println("Jenis Pembeli: " + jenisPasien);
                    System.out.println("____________________________________________________________");
                    System.out.print("Nama Obat" + "\t" + "Qty" + "\t" + "Harga" + "\t" + "Subtotal");
                    System.out.println();
                    for (int i = 0; i < dataObat.length; i++) {
                        System.out.print(namaObat[i]+ "\t\t");
                        for (int j = 0; j < dataObat[0].length; j++) {
                            System.out.print(dataObat[i][j] + "\t");
                        };
                        subtotal = dataObat[i][0] * dataObat[i][1];
                        System.out.println(subtotal+"\t");
                        total += (dataObat[i][0] * dataObat[i][1]);
                    }
                    System.out.println("_____________________________________________");
                    System.out.println("\t\t\tTotal : " + total);
                }else{
                    System.out.println("Struk tidak dapat tercetak tanpa transaksi!");
                }

            } else { 
                
            }
            System.out.println("Apa anda ingin memilih menu lain ?   [true/false]?");
            ulangi = sc.nextBoolean();
        }
    }else{
        System.out.println("Username/Password anda salah!");
    }
    }
}
